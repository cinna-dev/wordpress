<form method="get" action="<?= home_url(); ?>">
<input type="search" name="s" placeholder="Search Here..." value="<?= get_search_query(); ?>">
<input type="submit" id="search-btn" value=" ">
</form>