<?php get_header(); ?>

<h2>page.php</h2>

<?php get_footer(); ?>