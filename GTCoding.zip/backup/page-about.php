<?php get_header(); ?>

<h1>This is the page template for About page</h1>

<h2>page-about.php</h2>

<?php get_footer(); ?>