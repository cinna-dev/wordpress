<?php get_header(); ?>

<h2>singular.php</h2>

<?php get_footer(); ?>